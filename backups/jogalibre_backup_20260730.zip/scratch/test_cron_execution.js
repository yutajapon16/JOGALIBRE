const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });
const { Resend } = require('resend');

// Next.jsのエイリアスをモックまたはrequireで解決
const utils = require('./lib/utils.js');
const exchange = require('./lib/exchange.js');

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

let resendInstance = null;
function getResend() {
  if (!resendInstance) {
    resendInstance = new Resend(process.env.RESEND_API_KEY || 're_dummy_key');
  }
  return resendInstance;
}

async function sendOrderCsvEmail(to, csvContent, dateStr) {
  try {
    const resend = getResend();
    const dateStrUnderscore = dateStr.replace(/\//g, '_');
    console.log(`Sending email to ${to} with CSV content length: ${csvContent.length}`);
    const { data, error } = await resend.emails.send({
      from: 'JOGALIBRE Orders <order@jogalibre.com>',
      to: [to],
      subject: `[JOGALIBRE] 入札依頼（${dateStr}）[TEST]`,
      html: `<p>${dateStr} 時点での入札希望商品リストです。(Test Execution)</p>`,
      attachments: [
        {
          filename: `JOGALIBRE_入札依頼_${dateStrUnderscore}.csv`,
          content: Buffer.from('\uFEFF' + csvContent).toString('base64'),
        },
      ],
    });

    if (error) {
      console.error('Resend email error:', error);
      throw error;
    }

    console.log('Resend success data:', data);
    return data;
  } catch (error) {
    console.error('Failed to send email via Resend:', error);
    throw error;
  }
}

async function run() {
  try {
    console.log("Step 1: Exchange Rate Fetching...");
    let exchangeRate = 150;
    try {
      // lib/exchange.ts or js
      const rateData = await exchange.getResilientExchangeRate();
      exchangeRate = rateData.rates.JPY;
      console.log("Fetched Exchange Rate:", exchangeRate);
    } catch (err) {
      console.error('Error fetching exchange rate, using fallback:', err);
    }

    console.log("Step 2: Fetching Approved Orders...");
    const { data: orders, error: ordersError } = await supabase
      .from('bid_requests')
      .select('*')
      .eq('status', 'approved')
      .is('final_status', null)
      .eq('customer_confirmed', false)
      .order('product_end_time', { ascending: true });

    if (ordersError) throw ordersError;
    console.log(`Fetched ${orders ? orders.length : 0} orders.`);
    if (!orders || orders.length === 0) {
      console.log('No approved orders to export');
      return;
    }

    console.log("Step 3: Fetching Users...");
    const emails = Array.from(new Set(orders.map(o => o.customer_email)));
    const { data: users, error: usersError } = await supabase
      .from('user_roles')
      .select('email, customer_id, full_name, agent_customer_id, country')
      .in('email', emails);

    if (usersError) throw usersError;
    console.log(`Fetched ${users ? users.length : 0} users.`);

    const userMap = new Map(users?.map(u => [u.email, u]));

    console.log("Step 4: CSV Data Generation...");
    const csvHeaders = [
      'Order ID', 'End Time (JST)', 'Customer ID', 'Customer Name', 'Product Title',
      'Yahoo URL', 'Max Bid (JPY)', 'Shipping (JPY)', 'Max Bid (USD)', 'Exchange Rate',
      'Profit Rate', 'FOB (JPY)', 'Sent Date'
    ];

    const escapeCSV = (val) => {
      const str = String(val ?? '');
      return `"${str.replace(/"/g, '""')}"`;
    };

    const csvRows = orders.map((order, index) => {
      const userInfo = userMap.get(order.customer_email);
      const customerId = userInfo?.customer_id || 'Unknown';
      const customerName = userInfo?.full_name || order.customer_name || '';
      const agentCustomerId = userInfo?.agent_customer_id;

      let profitRate = 0.4;
      if (customerId === 'B001') {
        profitRate = 0.1;
      } else if (agentCustomerId === 'B001') {
        profitRate = 0.4;
      } else if (customerId.startsWith('A')) {
        profitRate = 0.2;
      }
      
      const rowIdx = index + 2;
      const formula = `=ROUNDDOWN((I${rowIdx}*J${rowIdx}*(1-K${rowIdx}))-L${rowIdx}-H${rowIdx},-3)`;

      const sentDate = order.sent_to_joga_at 
        ? new Date(order.sent_to_joga_at).toLocaleDateString('ja-JP', { timeZone: 'Asia/Tokyo' })
        : 'New';

      const rowFob = utils.calculateDefaultFobCost(order.product_title, order.product_url);
      const rowShipping = utils.calculateDefaultShippingCost(order.product_title, order.product_url);

      let finalMaxBidUsd = order.max_bid;
      if (order.customer_counter_offer_used) {
        finalMaxBidUsd = order.counter_offer || order.max_bid;
      } else if (order.customer_counter_offer) {
        finalMaxBidUsd = order.customer_counter_offer;
      }

      let maxBidUsdOutput = finalMaxBidUsd;
      const isB001Linked = agentCustomerId === 'B001';
      const isBrasilAgent = customerId.startsWith('A') && 
        ((userInfo?.country || '').trim().toLowerCase() === 'brasil' || (userInfo?.country || '').trim().toLowerCase() === 'brazil');

      if (isB001Linked || isBrasilAgent) {
        const itemDummy = {
          customerId,
          customer_id: customerId,
          agentCustomerId,
          agent_customer_id: agentCustomerId,
          country: userInfo?.country,
          customerCountry: userInfo?.country
        };
        maxBidUsdOutput = utils.calculateJapanSendAmount(itemDummy, finalMaxBidUsd, exchangeRate);
      }

      return [
        escapeCSV(order.id),
        escapeCSV(order.product_end_time),
        escapeCSV(customerId),
        escapeCSV(customerName),
        escapeCSV(order.product_title),
        escapeCSV(order.product_url),
        formula,
        rowShipping > 0 ? rowShipping : '',
        maxBidUsdOutput,
        exchangeRate,
        profitRate,
        rowFob,
        escapeCSV(sentDate)
      ].join(',');
    });

    const csvContent = [csvHeaders.join(','), ...csvRows].join('\n');
    console.log("Generated CSV successfully. Content preview:");
    console.log(csvContent);

    console.log("Step 5: Sending Email...");
    const dateStr = new Date().toLocaleDateString('ja-JP', { timeZone: 'Asia/Tokyo' });
    // テスト送信先を変更する場合はここを書き換えられますが、まずはコード全体が例外なく動くかを試すため、
    // 送信を呼び出します（Resendが失敗するか成功するかを確認）
    await sendOrderCsvEmail('export@joga.ltd', csvContent, dateStr);

    console.log("Execution finished successfully!");

  } catch (error) {
    console.error("CRITICAL ERROR IN CRON SIMULATION:", error);
  }
}

run();
