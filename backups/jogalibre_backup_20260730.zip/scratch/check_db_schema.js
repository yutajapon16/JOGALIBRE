const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  console.log("=== bid_requests テーブルのスキーマ（カラム一覧）を確認中 ===");
  try {
    // 1レコードだけ取得してキーを確認する
    const { data, error } = await supabase
      .from('bid_requests')
      .select('*')
      .limit(1);

    if (error) {
      console.error("エラー:", error);
      return;
    }

    if (data && data.length > 0) {
      console.log("レコードが見つかりました。カラム一覧:");
      console.log(Object.keys(data[0]));
    } else {
      console.log("データがありません。RPCやシステムカタログを使って確認します。");
      
      // システムカタログからカラム名を取得するクエリ
      const { data: cols, error: colsErr } = await supabase
        .rpc('get_table_columns', { table_name: 'bid_requests' })
        .catch(err => ({ error: err }));

      if (colsErr || !cols) {
        // SQLを直接投げる（可能であれば）
        const { data: cols2, error: colsErr2 } = await supabase
          .from('information_schema.columns')
          .select('column_name')
          .eq('table_name', 'bid_requests');
          
        if (colsErr2) {
          console.error("システムカタログからの取得も失敗しました:", colsErr2);
        } else {
          console.log("information_schema.columns から取得成功:");
          console.log(cols2.map(c => c.column_name));
        }
      } else {
        console.log("RPCから取得成功:", cols);
      }
    }

  } catch (e) {
    console.error("例外発生:", e);
  }
}

run();
