const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function setupAgentB001() {
  const email = 'order@jogalibre.com';
  const password = 'ffgn2326';
  const fullName = 'FFGN';
  const whatsapp = '+5518996686059';

  console.log(`B001エージェントアカウントの設定を開始します...`);

  try {
    // 1. Auth ユーザーの一覧から既存の order@jogalibre.com を検索
    const { data: usersData, error: fetchUserError } = await supabase.auth.admin.listUsers();
    if (fetchUserError) {
      console.error("ユーザーリストの取得に失敗しました:", fetchUserError.message);
      return;
    }

    const existingUser = usersData.users.find(u => u.email?.toLowerCase() === email.toLowerCase());

    let userId;

    if (existingUser) {
      console.log(`既存のユーザーが見つかりました（ID: ${existingUser.id}）。エージェント B001 にコンバートし、情報を更新します。`);
      userId = existingUser.id;

      // Auth メタデータとパスワードの更新（パスワードも更新して確実にログインできるようにする）
      const { error: updateAuthError } = await supabase.auth.admin.updateUserById(userId, {
        password: password,
        user_metadata: {
          ...existingUser.user_metadata,
          full_name: fullName,
          whatsapp: whatsapp,
          role: 'agent',
          agent_customer_id: null
        }
      });

      if (updateAuthError) {
        console.error("Authユーザー情報の更新に失敗しました:", updateAuthError.message);
        return;
      }
    } else {
      console.log(`新規ユーザーを作成します...`);
      // 新規作成
      const { data: authData, error: authError } = await supabase.auth.admin.createUser({
        email: email,
        password: password,
        email_confirm: true,
        user_metadata: {
          full_name: fullName,
          whatsapp: whatsapp,
          role: 'agent',
          agent_customer_id: null
        }
      });

      if (authError) {
        console.error("Authユーザーの新規作成に失敗しました:", authError.message);
        return;
      }

      userId = authData.user.id;
      console.log(`新規Authユーザーが作成されました。ID: ${userId}`);
    }

    // 2. user_roles テーブルに upsert（主キー id が競合したら更新）
    const { error: roleError } = await supabase
      .from('user_roles')
      .upsert({
        id: userId,
        email: email,
        role: 'agent',
        customer_id: 'B001',
        full_name: fullName,
        whatsapp: whatsapp,
        deposit_amount: 500,
        terms_accepted_at: new Date().toISOString()
      }, { onConflict: 'id' });

    if (roleError) {
      console.error("データベース(user_roles)の更新に失敗しました:", roleError.message);
      return;
    }

    console.log(`\n🎉 成功: エージェント B001 (メール: ${email}) の設定が完了しました！`);
    console.log(`表示名: ${fullName}`);
    console.log(`WhatsApp: ${whatsapp}`);
    console.log(`ロール: agent`);
    console.log(`エージェントID: B001`);

  } catch (error) {
    console.error("処理中に予期しないエラーが発生しました:", error);
  }
}

setupAgentB001();
