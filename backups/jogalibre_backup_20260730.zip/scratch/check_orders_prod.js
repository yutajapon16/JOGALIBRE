const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');

async function checkEnvFile(envPath) {
  if (!fs.existsSync(envPath)) {
    console.log(`\n=== ファイルが存在しません: ${envPath} ===`);
    return;
  }
  
  console.log(`\n=== 環境変数ファイル ${envPath} で確認中 ===`);
  const envContent = fs.readFileSync(envPath, 'utf-8');
  const env = {};
  envContent.split('\n').forEach(line => {
    const match = line.match(/^\s*([\w\.\-]+)\s*=\s*(.*)?\s*$/);
    if (match) {
      let key = match[1];
      let value = match[2] || '';
      // クォート除去
      if (value.startsWith('"') && value.endsWith('"')) {
        value = value.slice(1, -1);
      } else if (value.startsWith("'") && value.endsWith("'")) {
        value = value.slice(1, -1);
      }
      env[key] = value;
    }
  });

  const url = env.NEXT_PUBLIC_SUPABASE_URL;
  const key = env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !key) {
    console.log(`NEXT_PUBLIC_SUPABASE_URL または SUPABASE_SERVICE_ROLE_KEY が定義されていません。`);
    return;
  }

  console.log(`DB URL: ${url}`);
  const supabase = createClient(url, key);

  try {
    // 1. cron対象レコード
    const { data: cronTargetOrders, error: err1 } = await supabase
      .from('bid_requests')
      .select('id, status, final_status, customer_confirmed, created_at, product_title, sent_to_joga_at, product_end_time')
      .eq('status', 'approved')
      .is('final_status', null)
      .eq('customer_confirmed', false);

    if (err1) {
      console.error("エラー (cron対象取得):", err1);
    } else {
      console.log(`1. cron対象レコード (status='approved', final_status=null, customer_confirmed=false): ${cronTargetOrders.length}件`);
      cronTargetOrders.forEach(o => {
        console.log(`- ID: ${o.id}, Title: ${o.product_title}, CreatedAt: ${o.created_at}, SentAt: ${o.sent_to_joga_at}, EndTime: ${o.product_end_time}`);
      });
    }

    // 2. 2026-06-20 以降に作成されたレコード
    const { data: recentOrders, error: err2 } = await supabase
      .from('bid_requests')
      .select('id, status, final_status, customer_confirmed, created_at, product_title, sent_to_joga_at')
      .gte('created_at', '2026-06-20T00:00:00Z');

    if (err2) {
      console.error("エラー (最近のレコード取得):", err2);
    } else {
      console.log(`2. 2026/06/20以降に作成されたレコード: ${recentOrders.length}件`);
      recentOrders.forEach(o => {
        console.log(`- ID: ${o.id}, Title: ${o.product_title}, Status: ${o.status}, FinalStatus: ${o.final_status}, Confirmed: ${o.customer_confirmed}, CreatedAt: ${o.created_at}`);
      });
    }
  } catch (e) {
    console.error("エラー発生:", e);
  }
}

async function run() {
  await checkEnvFile('.env.vercel.pulled');
}

run();
