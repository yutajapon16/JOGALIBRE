const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY,
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  }
);

async function run() {
  const oldEmail = 'export@joga.ltd';
  const newEmail = 'admin@jogalibre.com';
  const newPassword = 'ffgn2326';

  console.log(`Searching for user with email: ${oldEmail}`);

  try {
    // 1. ユーザー一覧を取得して旧管理者の ID を特定
    const { data: { users }, error: listError } = await supabase.auth.admin.listUsers();
    if (listError) {
      console.error("Error listing users:", listError);
      return;
    }

    const adminUser = users.find(u => u.email?.toLowerCase() === oldEmail.toLowerCase());

    if (!adminUser) {
      console.log(`User ${oldEmail} not found in Supabase Auth.`);
      // すでに更新済みか、または別のアカウント名で登録されている可能性を考慮し、新規登録ユーザー一覧を表示してみる
      console.log("Current users in Auth:");
      users.forEach(u => console.log(`- ID: ${u.id}, Email: ${u.email}, Role: ${u.user_metadata?.role}`));
      return;
    }

    console.log(`Found admin user! ID: ${adminUser.id}`);

    // 2. Auth側のメールアドレスとパスワードを更新
    console.log(`Updating auth user to Email: ${newEmail}, Password: ${newPassword}...`);
    const { data: updatedUser, error: updateAuthError } = await supabase.auth.admin.updateUserById(
      adminUser.id,
      {
        email: newEmail,
        password: newPassword,
        email_confirm: true // メール認証をスキップして即時確定
      }
    );

    if (updateAuthError) {
      console.error("Error updating auth user:", updateAuthError);
      return;
    }

    console.log("Auth user updated successfully!");

    // 3. user_roles テーブルの更新
    console.log("Checking user_roles table...");
    const { data: roleData, error: selectRoleError } = await supabase
      .from('user_roles')
      .select('*')
      .eq('id', adminUser.id)
      .maybeSingle();

    if (selectRoleError) {
      console.error("Error checking user_roles:", selectRoleError);
    } else if (roleData) {
      console.log("Found user_roles record:", roleData);
      
      const updateData = {};
      // もし email カラムがあれば更新
      if ('email' in roleData) {
        updateData.email = newEmail;
      }
      // もし role が admin でない場合は admin に設定
      if (roleData.role !== 'admin') {
        updateData.role = 'admin';
      }

      if (Object.keys(updateData).length > 0) {
        console.log("Updating user_roles with:", updateData);
        const { error: updateRoleError } = await supabase
          .from('user_roles')
          .update(updateData)
          .eq('id', adminUser.id);

        if (updateRoleError) {
          console.error("Error updating user_roles:", updateRoleError);
        } else {
          console.log("user_roles updated successfully!");
        }
      } else {
        console.log("No updates needed for user_roles.");
      }
    } else {
      console.log("No user_roles record found for this user ID. Inserting one as admin...");
      const { error: insertRoleError } = await supabase
        .from('user_roles')
        .insert({
          id: adminUser.id,
          email: newEmail,
          role: 'admin',
          full_name: '管理者'
        });
      if (insertRoleError) {
        console.error("Error inserting user_roles:", insertRoleError);
      } else {
        console.log("Inserted user_roles record successfully!");
      }
    }

  } catch (e) {
    console.error("Exception occurred:", e);
  }
}

run();
