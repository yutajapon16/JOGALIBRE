const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  console.log("Inspecting bid_requests table...");
  try {
    const { data, error } = await supabaseAdmin
      .from('bid_requests')
      .select('*')
      .limit(1);

    if (error) {
      console.error("SELECT FAILED WITH ERROR:", error);
    } else {
      console.log("Columns & Sample Record:", data);
    }
  } catch (e) {
    console.error("Script error:", e);
  }
}

run();
