const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  console.log("=== 2026/06/18 以降に作成されたすべてのレコードを検索中 ===");
  try {
    const { data: orders, error } = await supabase
      .from('bid_requests')
      .select('id, status, final_status, customer_confirmed, created_at, product_title, sent_to_joga_at, product_end_time')
      .gte('created_at', '2026-06-18T00:00:00Z')
      .order('created_at', { ascending: false });

    if (error) {
      console.error("エラー:", error);
      return;
    }

    console.log(`取得件数: ${orders.length}件`);
    orders.forEach(o => {
      console.log(`- ID: ${o.id}`);
      console.log(`  Title: ${o.product_title}`);
      console.log(`  CreatedAt: ${o.created_at}`);
      console.log(`  Status: ${o.status}, FinalStatus: ${o.final_status}, Confirmed: ${o.customer_confirmed}`);
      console.log(`  SentToJogaAt: ${o.sent_to_joga_at}`);
      console.log(`  ProductEndTime: ${o.product_end_time}`);
      console.log('-----------------------------');
    });

  } catch (e) {
    console.error("エラー発生:", e);
  }
}

run();
