async function run() {
  console.log("ヤフオク検索ページから商品URLを探索中...");
  try {
    const url = 'https://auctions.yahoo.co.jp/search/search?p=wheel';
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      }
    });
    const html = await res.text();
    
    // a hrefの中身をすべて探す
    const aHrefRegex = /href="([^"]*)"/g;
    let match;
    const auctionLinks = [];
    while ((match = aHrefRegex.exec(html)) !== null) {
      const link = match[1];
      if (link.includes('/jp/auction/') || link.includes('page.auctions.yahoo.co.jp')) {
        auctionLinks.push(link);
      }
    }
    
    console.log(`見つかったオークションURL件数: ${auctionLinks.length}`);
    if (auctionLinks.length > 0) {
      const uniqueLinks = Array.from(new Set(auctionLinks));
      console.log("ユニークリンク数:", uniqueLinks.length);
      console.log("最初の数件:");
      uniqueLinks.slice(0, 5).forEach(l => console.log("- " + l));
    } else {
      console.log("リンクが見つかりません。HTMLから 'jp/auction/' を含む部分を検索します:");
      const index = html.indexOf('/jp/auction/');
      if (index !== -1) {
        console.log("周辺のHTML:", html.substring(index - 100, index + 200));
      } else {
        console.log("'/jp/auction/' という文字列自体が存在しません。");
      }
    }
  } catch (e) {
    console.error("エラー:", e);
  }
}

run();
