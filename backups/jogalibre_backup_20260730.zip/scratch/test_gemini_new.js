async function testGeminiUrl(apiKey) {
  console.log('\n--- Testing with URL Param and gemini-2.5-flash ---');
  const url = `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
  
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: 'Say hello in Spanish.'
          }]
        }]
      })
    });
    
    console.log('URL Method - Response Status:', response.status);
    const text = await response.text();
    console.log('URL Method - Response Body:', text);
  } catch (error) {
    console.error('URL Method - Fetch Error:', error);
  }
}

const key = "AQ.Ab8RN6Ifql_SPYsd19YaMZmq7ebOmSRR_M26S5BcMdnEKHzKyw";
async function run() {
  await testGeminiUrl(key);
}
run();
