const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  console.log("=== Users in user_roles ===");
  const { data: users, error: userError } = await supabase
    .from('user_roles')
    .select('id, customer_id, email, role, full_name, language');
  if (userError) {
    console.error("userError:", userError);
  } else {
    users.forEach(u => {
      console.log(`Email: ${u.email} | ID: ${u.customer_id} | Role: ${u.role} | Name: ${u.full_name} | Lang: ${u.language}`);
    });
  }

  console.log("\n=== Bid Requests with shipping status ===");
  const { data: bids, error: bidError } = await supabase
    .from('bid_requests')
    .select('id, product_title, customer_email, delivery_location, shipping_status, final_price');
  if (bidError) {
    console.error("bidError:", bidError);
  } else {
    bids.forEach(b => {
      console.log(`ID: ${b.id} | Email: ${b.customer_email} | Title: ${b.product_title.substring(0, 30)}... | Status: ${b.shipping_status} | Loc: ${b.delivery_location} | Price: ${b.final_price}`);
    });
  }
}

run();
