const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  console.log("Checking if 'language' column exists in 'user_roles'...");
  try {
    const { data, error } = await supabase
      .from('user_roles')
      .select('id, email, language')
      .limit(1);

    if (error) {
      console.error("Database query returned an error:", error);
    } else {
      console.log("Success! Columns verified. Data sample:", data);
    }
  } catch (e) {
    console.error("Execution failed:", e);
  }
}

run();
