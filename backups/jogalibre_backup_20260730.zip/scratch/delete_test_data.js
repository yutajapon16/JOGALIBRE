const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  const targetCustomerIds = ['C001', 'A003'];
  console.log(`Step 1: Retrieving emails for customer IDs: ${targetCustomerIds.join(', ')} from user_roles...`);
  
  try {
    // 1. user_rolesから該当IDのメールアドレスを取得
    const { data: userData, error: userError } = await supabaseAdmin
      .from('user_roles')
      .select('email, customer_id')
      .in('customer_id', targetCustomerIds);

    if (userError) {
      console.error("Failed to fetch user roles:", userError);
      return;
    }

    console.log(`Found ${userData.length} matching users in user_roles:`);
    userData.forEach(user => {
      console.log(`- Customer ID: ${user.customer_id}, Email: ${user.email}`);
    });

    const targetEmails = userData.map(u => u.email).filter(Boolean);
    if (targetEmails.length === 0) {
      console.log("No emails found for these customer IDs. Exiting.");
      return;
    }

    // 2. bid_requestsから件数確認
    console.log(`\nStep 2: Checking bid_requests for emails: ${targetEmails.join(', ')}...`);
    const { data: selectData, error: selectError } = await supabaseAdmin
      .from('bid_requests')
      .select('id, customer_email, product_title, final_status')
      .in('customer_email', targetEmails);

    if (selectError) {
      console.error("SELECT FAILED:", selectError);
      return;
    }

    console.log(`Found ${selectData.length} records in bid_requests:`);
    selectData.forEach(row => {
      const matchedUser = userData.find(u => u.email === row.customer_email);
      const custId = matchedUser ? matchedUser.customer_id : 'Unknown';
      console.log(`- ID: ${row.id}, CustomerID: ${custId}, Email: ${row.customer_email}, Title: ${row.product_title}, FinalStatus: ${row.final_status}`);
    });

    if (selectData.length === 0) {
      console.log("No records found to delete in bid_requests. Exiting.");
      return;
    }

    // 3. 削除の実行
    console.log("\nStep 3: Deleting bid_requests records...");
    const { data: deleteData, error: deleteError } = await supabaseAdmin
      .from('bid_requests')
      .delete()
      .in('customer_email', targetEmails)
      .select();

    if (deleteError) {
      console.error("DELETE FAILED:", deleteError);
    } else {
      console.log(`SUCCESS: Deleted ${deleteData.length} records from bid_requests.`);
    }
  } catch (e) {
    console.error("Script execution error:", e);
  }
}

run();
