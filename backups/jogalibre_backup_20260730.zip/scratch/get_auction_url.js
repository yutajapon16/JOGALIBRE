async function run() {
  console.log("ヤフオクのトップページから商品URLを探索中...");
  try {
    const res = await fetch('https://auctions.yahoo.co.jp/', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      }
    });
    const html = await res.text();
    
    // オークションURLの正規表現
    const regex = /href="([^"]*page\.auctions\.yahoo\.co\.jp\/jp\/auction\/[a-zA-Z0-9]+[^"]*)"/g;
    let match;
    const urls = [];
    while ((match = regex.exec(html)) !== null) {
      urls.push(match[1]);
    }
    
    console.log(`見つかったURL件数: ${urls.length}`);
    if (urls.length > 0) {
      console.log("最初のURL:", urls[0]);
    } else {
      // 簡易検索で /jp/auction/ の文字だけ探す
      const regexSimple = /"([^"]*\/jp\/auction\/[a-zA-Z0-9]+[^"]*)"/g;
      const simpleUrls = [];
      let matchS;
      while ((matchS = regexSimple.exec(html)) !== null) {
        simpleUrls.push(matchS[1]);
      }
      console.log(`簡易検索で見つかったURL件数: ${simpleUrls.length}`);
      if (simpleUrls.length > 0) {
        console.log("最初の簡易URL:", simpleUrls[0]);
      } else {
        console.log("HTMLサイズ:", html.length);
        console.log("一部HTML:", html.substring(0, 1000));
      }
    }
  } catch (e) {
    console.error("エラー:", e);
  }
}

run();
