const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  console.log("Checking columns in bid_requests...");
  try {
    const { data, error } = await supabase
      .from('bid_requests')
      .select('*')
      .limit(1);

    if (error) {
      console.error("DB Error:", error);
      return;
    }

    if (!data || data.length === 0) {
      console.log("No records found in bid_requests. Columns check via empty response is not fully descriptive but let's see keys:");
    } else {
      console.log("Found columns:", Object.keys(data[0]));
    }
  } catch (e) {
    console.error("Script error:", e);
  }
}

run();
