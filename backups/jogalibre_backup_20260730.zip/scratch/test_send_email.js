const { createClient } = require('@supabase/supabase-js');
const { Resend } = require('resend');
require('dotenv').config({ path: '.env.local' });

// 遅延初期化の代わり
const resend = new Resend(process.env.RESEND_API_KEY || 're_dummy_key');

async function sendOrderCsvEmail(to, csvContent, dateStr) {
  try {
    const dateStrUnderscore = dateStr.replace(/\//g, '_');
    const emailPayload = {
      from: 'JOGALIBRE Orders <order@jogalibre.com>',
      to: [to],
      subject: `[JOGALIBRE] 入札依頼（${dateStr}）[TEST]`,
      html: `<p>${dateStr} 時点での入札希望商品リストです。(テスト送信)</p>`,
      attachments: [
        {
          filename: `JOGALIBRE_入札依頼_${dateStrUnderscore}.csv`,
          content: Buffer.from('\uFEFF' + csvContent).toString('base64'),
        },
      ],
    };

    console.log("Sending email payload via Resend:", JSON.stringify(emailPayload, null, 2).substring(0, 500) + "...");
    const { data, error } = await resend.emails.send(emailPayload);

    if (error) {
      console.error('Resend email error:', error);
      throw error;
    }

    console.log("Resend Success Response Data:", data);
    return data;
  } catch (error) {
    console.error('Failed to send email via Resend:', error);
    throw error;
  }
}

async function run() {
  console.log("Starting email send test...");
  try {
    const csvContent = "Order ID,Product Title,Status\n1234,Test Product,approved";
    const dateStr = new Date().toLocaleDateString('ja-JP', { timeZone: 'Asia/Tokyo' });
    
    // export-orders cronと同じ宛先にテスト送信を試みる
    await sendOrderCsvEmail('export@joga.ltd', csvContent, dateStr);
    console.log("Test finished successfully!");
  } catch (e) {
    console.error("Test failed with error:", e);
  }
}

run();
