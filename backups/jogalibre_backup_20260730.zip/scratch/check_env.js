const fs = require('fs');
require('dotenv').config({ path: '.env.local' });

console.log("=== 環境変数の確認 ===");
const keys = Object.keys(process.env);
const dbKeys = keys.filter(k => k.toLowerCase().includes('db') || k.toLowerCase().includes('postgres') || k.toLowerCase().includes('sql') || k.toLowerCase().includes('conn'));
console.log("DB関連と思われる環境変数:", dbKeys);
dbKeys.forEach(k => {
  console.log(`- ${k}: ${process.env[k] ? '設定あり' : '空'}`);
});
