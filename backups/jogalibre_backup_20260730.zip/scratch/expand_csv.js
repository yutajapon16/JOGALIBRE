const fs = require('fs');
const path = require('path');

const csvPath = path.resolve(__dirname, '../data/local-costs.csv');

// Shift-JISまたはUTF-8で読み込み
const buffer = fs.readFileSync(csvPath);
let content = '';
try {
  const sjisDecoder = new TextDecoder('shift-jis', { fatal: true });
  content = sjisDecoder.decode(buffer);
  console.log('Decoded as Shift-JIS successfully.');
} catch (e) {
  content = buffer.toString('utf-8');
  console.log('Decoded as UTF-8.');
}

const lines = content.split(/\r?\n/).filter(line => line.trim() !== '');

// パースと拡張
const newLines = [];

// ヘッダー行
// 既存: key,asu_sea,cde_sea,enc_sea,pjc_sea,asu_air,cde_air,enc_air,pjc_air
// 新規: key,asu_sea,cde_sea,enc_sea,pjc_sea,snt_sea,iqq_sea,lpz_sea,scz_sea,bue_sea,asu_air,cde_air,enc_air,pjc_air,snt_air,iqq_air,lpz_air,scz_air,bue_air
const header = 'key,asu_sea,cde_sea,enc_sea,pjc_sea,snt_sea,iqq_sea,lpz_sea,scz_sea,bue_sea,asu_air,cde_air,enc_air,pjc_air,snt_air,iqq_air,lpz_air,scz_air,bue_air';
newLines.push(header);

for (let i = 1; i < lines.length; i++) {
  const cols = lines[i].split(',').map(c => c.trim());
  const key = cols[0];
  
  // 元の値を格納
  const asu_sea = cols[1] || '0';
  const cde_sea = cols[2] || '0';
  const enc_sea = cols[3] || '0';
  const pjc_sea = cols[4] || '0';
  const asu_air = cols[5] || '0';
  const cde_air = cols[6] || '0';
  const enc_air = cols[7] || '0';
  const pjc_air = cols[8] || '0';

  // 新規都市用の値の決定
  let snt_sea = '0', iqq_sea = '0', lpz_sea = '0', scz_sea = '0', bue_sea = '0';
  let snt_air = '0', iqq_air = '0', lpz_air = '0', scz_air = '0', bue_air = '0';

  const isUnavailableAir = asu_air === '発送不可' || asu_air === 's';
  const isQuerySea = asu_sea === '要問い合わせ' || asu_sea === 'v₢キング' || asu_sea === 'v₢キング' || asu_sea.includes('₢');

  if (isUnavailableAir) {
    snt_air = '発送不可';
    iqq_air = '発送不可';
    lpz_air = '発送不可';
    scz_air = '発送不可';
    bue_air = '発送不可';
  }
  if (isQuerySea) {
    snt_sea = '要問い合わせ';
    iqq_sea = '要問い合わせ';
    lpz_sea = '要問い合わせ';
    scz_sea = '要問い合わせ';
    bue_sea = '要問い合わせ';
  }

  // クリーンアップ
  const cleanVal = (val) => {
    if (val.includes('₢') || val.includes('v')) return '要問い合わせ';
    if (val.includes('s') || val.includes('発送不可')) return '発送不可';
    return val;
  };

  const row = [
    key,
    cleanVal(asu_sea),
    cleanVal(cde_sea),
    cleanVal(enc_sea),
    cleanVal(pjc_sea),
    snt_sea,
    iqq_sea,
    lpz_sea,
    scz_sea,
    bue_sea,
    cleanVal(asu_air),
    cleanVal(cde_air),
    cleanVal(enc_air),
    cleanVal(pjc_air),
    snt_air,
    iqq_air,
    lpz_air,
    scz_air,
    bue_air
  ];
  newLines.push(row.join(','));
}

fs.writeFileSync(csvPath, newLines.join('\n'), 'utf-8');
console.log('Expanded CSV successfully written to UTF-8.');
