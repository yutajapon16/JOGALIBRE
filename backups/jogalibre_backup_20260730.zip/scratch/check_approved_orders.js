const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  console.log("Checking for approved bid_requests to export...");
  try {
    // 2. 「承認済」ステータスの全注文を取得（送信済み・未送信を問わず、現在の全タスクリスト）
    // cron/export-orders/route.ts のクエリと同じ条件で取得する
    const { data: orders, error: ordersError } = await supabase
      .from('bid_requests')
      .select('id, status, final_status, customer_confirmed, customer_email, product_title, product_url, max_bid, sent_to_joga_at')
      .eq('status', 'approved')
      .is('final_status', null)
      .eq('customer_confirmed', false);

    if (ordersError) {
      console.error("DB Error:", ordersError);
      return;
    }

    console.log(`Found ${orders.length} approved orders matching the cron criteria.`);
    
    if (orders.length > 0) {
      orders.forEach((o, index) => {
        console.log(`\n[Order ${index + 1}]`);
        console.log(`ID: ${o.id}`);
        console.log(`Customer Email: ${o.customer_email}`);
        console.log(`Title: ${o.product_title}`);
        console.log(`URL: ${o.product_url}`);
        console.log(`Max Bid (USD): ${o.max_bid}`);
        console.log(`Sent to Joga At: ${o.sent_to_joga_at}`);
      });
    }

  } catch (e) {
    console.error("Script error:", e);
  }
}

run();
