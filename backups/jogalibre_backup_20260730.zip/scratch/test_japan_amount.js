// 日本支払額の計算式テストスクリプト

function calculateJapanSendAmount(item, totalSalePrice) {
  if (item.customerId === 'B001') {
    return totalSalePrice;
  }
  let ownDivisor = 0.6; // デフォルト: 一般顧客 (利益率40%＝除数0.6)
  let targetDivisor = 0.9; // デフォルト: B001本人の仕入れ割合 (利益率10%＝除数0.9)
  
  if (item.agentCustomerId === 'B001') {
    ownDivisor = 0.5; // B001紐づき (利益率50%＝除数0.5)
    targetDivisor = 0.6; // 一般顧客 (利益率40%＝除数0.6)
  } else if (item.customerId?.startsWith('A')) {
    const countryLower = item.customerCountry?.trim().toLowerCase();
    if (countryLower === 'brasil' || countryLower === 'brazil') {
      ownDivisor = 0.7; // ブラジルエージェント (利益率30%＝除数0.7)
      targetDivisor = 0.8; // 通常エージェント (利益率20%＝除数0.8)
    } else {
      ownDivisor = 0.8; // 通常エージェント (利益率20%＝除数0.8)
      targetDivisor = 0.9; // B001本人 (利益率10%＝除数0.9)
    }
  }
  return Math.ceil(((totalSalePrice * ownDivisor) / targetDivisor) / 10) * 10;
}

// テスト実行
console.log('--- テスト 1-1: B001紐づき顧客 (希望入札額) ---');
const testItem1 = {
  customerId: 'C001',
  agentCustomerId: 'B001',
  customerCountry: 'Japan'
};
const result1 = calculateJapanSendAmount(testItem1, 730);
console.log(`売価 $730 ➡️ 日本支払額: $${result1} (期待値: $610)`);
if (result1 === 610) {
  console.log('✅ テスト 1-1 成功');
} else {
  console.log('❌ テスト 1-1 失敗');
}

console.log('\n--- テスト 1-2: B001紐づき顧客 (カウンターオファー) ---');
const result1_2 = calculateJapanSendAmount(testItem1, 700);
console.log(`売価 $700 ➡️ 日本支払額: $${result1_2} (期待値: $590)`);
if (result1_2 === 590) {
  console.log('✅ テスト 1-2 成功');
} else {
  console.log('❌ テスト 1-2 失敗');
}

console.log('\n--- テスト 2: ブラジルエージェント ---');
const testItem2 = {
  customerId: 'A001',
  agentCustomerId: null,
  customerCountry: 'Brasil'
};
const result2 = calculateJapanSendAmount(testItem2, 520);
console.log(`売価 $520 ➡️ 日本支払額: $${result2} (期待値: $460)`);
if (result2 === 460) {
  console.log('✅ テスト 2 成功');
} else {
  console.log('❌ テスト 2 失敗');
}

console.log('\n--- テスト 3: 通常エージェント ---');
const testItem3 = {
  customerId: 'A002',
  agentCustomerId: null,
  customerCountry: 'Paraguay'
};
const result3 = calculateJapanSendAmount(testItem3, 100);
// 通常エージェント: ownDivisor = 0.8, targetDivisor = 0.9
// Math.ceil(((100 * 0.8) / 0.9) / 10) * 10 ➡️ 80 / 0.9 = 88.88 ➡️ 切り上げて $90
console.log(`売価 $100 ➡️ 日本支払額: $${result3} (期待値: $90)`);
if (result3 === 90) {
  console.log('✅ テスト 3 成功');
} else {
  console.log('❌ テスト 3 失敗');
}
