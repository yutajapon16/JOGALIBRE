async function testScraping(url) {
  console.log(`テスト開始: ${url}`);
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      }
    });
    
    if (!response.ok) {
      console.error(`HTTP エラー: ${response.status} ${response.statusText}`);
      return;
    }
    
    const html = await response.text();
    console.log(`HTML取得成功。サイズ: ${html.length} bytes`);
    
    // __NEXT_DATA__ の抽出テスト
    const nextDataMatch = html.match(/<script id="__NEXT_DATA__" type="application\/json">(.+?)<\/script>/);
    console.log(`__NEXT_DATA__ の存在: ${!!nextDataMatch}`);
    
    let title = '';
    let currentPrice = 0;
    let bids = 0;
    let imageUrl = '';
    let endTime = null;
    let shippingCost = 0;
    let shippingUnknown = false;
    let allImages = [];
    let description = '';

    if (nextDataMatch) {
      try {
        const jsonData = JSON.parse(nextDataMatch[1]);
        const pageProps = jsonData.props?.pageProps;
        console.log("pagePropsの存在:", !!pageProps);
        if (pageProps) {
          const initialState = pageProps.initialState;
          console.log("initialStateの存在:", !!initialState);
          if (initialState) {
            const itemData = initialState.item?.detail?.item || {};
            console.log("itemDataのキー一覧:", Object.keys(itemData));
            
            currentPrice = itemData.taxinPrice ||
              itemData.taxinStartPrice ||
              itemData.price ||
              itemData.currentPrice ||
              itemData.currentBidPrice ||
              itemData.startPrice ||
              0;

            bids = itemData.bids ||
              itemData.bidCount ||
              itemData.numberOfBids ||
              itemData.bidders ||
              itemData.bidOrBuy ||
              0;

            title = itemData.title ||
              itemData.name ||
              itemData.productName ||
              '';
              
            console.log("抽出結果 (JSON):", { title, currentPrice, bids });
            
            if (Array.isArray(itemData.img)) {
              allImages = itemData.img.map(img => img.image || img.url || img.thumbnail).filter(Boolean);
            }
            console.log("画像数:", allImages.length);
            
            if (itemData.endTime) {
              console.log("endTime (raw):", itemData.endTime, typeof itemData.endTime);
            }
          }
        }
      } catch (e) {
        console.error("JSONパースエラー:", e);
      }
    }
    
    // フォールバックタイトル
    if (!title) {
      const titleMatch = html.match(/<h1[^>]*>([^<]+)<\/h1>/i);
      if (titleMatch) title = titleMatch[1].trim();
      console.log("フォールバックタイトル抽出:", title);
    }
    
    // 抽出が全体的に成功しているか
    console.log("最終判定結果:");
    console.log("- タイトル:", title);
    console.log("- 現在価格:", currentPrice);
    console.log("- 入札数:", bids);
    
  } catch (e) {
    console.error("スクレイピング処理全体でのエラー:", e);
  }
}

// テスト実行
const testUrl = 'https://auctions.yahoo.co.jp/jp/auction/1234475905';
testScraping(testUrl);
