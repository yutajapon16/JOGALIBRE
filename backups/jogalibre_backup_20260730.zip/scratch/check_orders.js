const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  console.log("=== DBのbid_requestsテーブルの状況確認 ===");
  try {
    // 1. 本来cronの対象となるはずのレコード（status=approved, final_status=null, customer_confirmed=false）
    const { data: cronTargetOrders, error: err1 } = await supabase
      .from('bid_requests')
      .select('id, status, final_status, customer_confirmed, created_at, product_title, sent_to_joga_at, product_end_time')
      .eq('status', 'approved')
      .is('final_status', null)
      .eq('customer_confirmed', false);

    if (err1) {
      console.error("エラー (cron対象取得):", err1);
    } else {
      console.log(`\n1. cron対象レコード (status='approved', final_status=null, customer_confirmed=false): ${cronTargetOrders.length}件`);
      cronTargetOrders.forEach(o => {
        console.log(`- ID: ${o.id}, Title: ${o.product_title}, CreatedAt: ${o.created_at}, SentAt: ${o.sent_to_joga_at}, EndTime: ${o.product_end_time}`);
      });
    }

    // 2. status='approved' かつ final_status=null のレコード（customer_confirmed問わず）
    const { data: allApprovedOrders, error: err2 } = await supabase
      .from('bid_requests')
      .select('id, status, final_status, customer_confirmed, created_at, product_title, sent_to_joga_at')
      .eq('status', 'approved')
      .is('final_status', null);

    if (err2) {
      console.error("エラー (approved全取得):", err2);
    } else {
      console.log(`\n2. status='approved', final_status=null のレコード全件: ${allApprovedOrders.length}件`);
      allApprovedOrders.forEach(o => {
        console.log(`- ID: ${o.id}, Title: ${o.product_title}, CustomerConfirmed: ${o.customer_confirmed}, CreatedAt: ${o.created_at}, SentAt: ${o.sent_to_joga_at}`);
      });
    }

    // 3. 2026-06-20 以降に作成されたレコード
    const { data: recentOrders, error: err3 } = await supabase
      .from('bid_requests')
      .select('id, status, final_status, customer_confirmed, created_at, product_title, sent_to_joga_at')
      .gte('created_at', '2026-06-20T00:00:00Z');

    if (err3) {
      console.error("エラー (最近のレコード取得):", err3);
    } else {
      console.log(`\n3. 2026/06/20以降に作成されたレコード: ${recentOrders.length}件`);
      recentOrders.forEach(o => {
        console.log(`- ID: ${o.id}, Title: ${o.product_title}, Status: ${o.status}, FinalStatus: ${o.final_status}, Confirmed: ${o.customer_confirmed}, CreatedAt: ${o.created_at}`);
      });
    }

  } catch (e) {
    console.error("実行時エラー:", e);
  }
}

run();
