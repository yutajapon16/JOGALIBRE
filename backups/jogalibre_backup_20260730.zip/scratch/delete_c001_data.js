const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const C001_EMAIL = 'y-fujii@joga.ltd';

async function run() {
  console.log(`Starting simple deletion for customer_email = ${C001_EMAIL}...`);

  try {
    const { data: bidsDeleted, error: bidsError } = await supabase
      .from('bid_requests')
      .delete()
      .eq('customer_email', C001_EMAIL)
      .select('id, product_title');

    if (bidsError) {
      console.error("Error deleting bid_requests:", bidsError);
    } else {
      console.log(`Successfully deleted ${bidsDeleted ? bidsDeleted.length : 0} bid_requests:`);
      if (bidsDeleted) {
        bidsDeleted.forEach(b => console.log(` - Deleted Bid ID: ${b.id}, Title: ${b.product_title}`));
      }
    }
  } catch (e) {
    console.error("Exception occurred:", e);
  }
}

run();
