const fs = require('fs');
const path = require('path');

const files = [
  'data/shipping-costs.csv',
  'data/fob-costs.csv',
  'data/local-costs.csv'
];

files.forEach(f => {
  const filePath = path.resolve(__dirname, '..', f);
  if (!fs.existsSync(filePath)) {
    console.warn(`File not found: ${filePath}`);
    return;
  }
  const buffer = fs.readFileSync(filePath);
  
  // すでにBOMがあるかチェック
  if (buffer.length >= 3 && buffer[0] === 0xEF && buffer[1] === 0xBB && buffer[2] === 0xBF) {
    console.log(`${f} already has BOM. Skipping.`);
    return;
  }

  let content = '';
  // Shift-JISまたはUTF-8で安全にデコード
  try {
    const sjisDecoder = new TextDecoder('shift-jis', { fatal: true });
    content = sjisDecoder.decode(buffer);
    console.log(`Decoded ${f} as Shift-JIS`);
  } catch (e) {
    content = buffer.toString('utf-8');
    console.log(`Decoded ${f} as UTF-8`);
  }

  // BOM（\uFEFF）を付与してUTF-8で保存
  const bomBuffer = Buffer.concat([
    Buffer.from([0xEF, 0xBB, 0xBF]), // UTF-8 BOM
    Buffer.from(content, 'utf-8')
  ]);

  fs.writeFileSync(filePath, bomBuffer);
  console.log(`Saved ${f} as UTF-8 with BOM successfully.`);
});
