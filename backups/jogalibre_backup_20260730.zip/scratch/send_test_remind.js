const { createClient } = require('@supabase/supabase-js');
const { Resend } = require('resend');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

const resend = new Resend(process.env.RESEND_API_KEY);

async function run() {
  console.log("=== C001へのテストメール送信開始 ===");
  try {
    // 1. C001ユーザーをDBから取得
    const { data: user, error: fetchError } = await supabase
      .from('user_roles')
      .select('id, email, full_name, role, language')
      .eq('customer_id', 'C001')
      .maybeSingle();

    if (fetchError) {
      console.error("C001ユーザー取得に失敗しました:", fetchError);
      return;
    }

    if (!user) {
      console.error("C001ユーザーが見つかりません。");
      return;
    }

    console.log(`C001ユーザー情報:`);
    console.log(`- ID: ${user.id}`);
    console.log(`- Email: ${user.email}`);
    console.log(`- Name: ${user.full_name}`);
    console.log(`- Language: ${user.language}`);

    if (!user.email) {
      console.error("メールアドレスが設定されていません。");
      return;
    }

    const lang = (user.language || 'es').toLowerCase();
    const isPt = lang === 'pt';
    
    const subject = isPt 
      ? 'Sentimos sua falta no JOGALIBRE! (Test)' 
      : '¡Te extrañamos en JOGALIBRE! (Test)';
      
    const html = isPt 
      ? `
        <div style="font-family: sans-serif; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eee; border-radius: 10px;">
          <h2 style="color: #4f46e5; margin-bottom: 20px;">Sentimos sua falta no JOGALIBRE! [Test]</h2>
          <p>Olá, <strong>${user.full_name || 'Usuário'}</strong>,</p>
          <p>Faz tempo que você não entra na plataforma JOGALIBRE.</p>
          <p>Convidamos você a fazer login e enviar suas solicitações de lance para os produtos de seu interesse.</p>
          <div style="margin: 30px 0; text-align: center;">
            <a href="https://jogalibre.vercel.app/" style="background-color: #4f46e5; color: #fff; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">Acessar o JOGALIBRE</a>
          </div>
          <hr style="border: 0; border-top: 1px solid #eee; margin: 30px 0;" />
          <p style="font-size: 11px; color: #888;">Este é um e-mail automático de teste. Por favor, não responda diretamente a esta mensagem.</p>
        </div>
      `
      : `
        <div style="font-family: sans-serif; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eee; border-radius: 10px;">
          <h2 style="color: #4f46e5; margin-bottom: 20px;">¡Te extrañamos en JOGALIBRE! [Test]</h2>
          <p>Hola, <strong>${user.full_name || 'Usuario'}</strong>,</p>
          <p>Hace tiempo que no ingresas a la plataforma JOGALIBRE.</p>
          <p>Te invitamos a iniciar sesión y realizar tu solicitud de oferta (ofertar) por los productos de tu interés.</p>
          <div style="margin: 30px 0; text-align: center;">
            <a href="https://jogalibre.vercel.app/" style="background-color: #4f46e5; color: #fff; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">Acceder a JOGALIBRE</a>
          </div>
          <hr style="border: 0; border-top: 1px solid #eee; margin: 30px 0;" />
          <p style="font-size: 11px; color: #888;">Este es un correo automático de prueba. Por favor, no respondas directamente a este mensaje.</p>
        </div>
      `;

    // 2. Resendでメール送信
    console.log(`Sending test email to ${user.email} using language: ${lang}...`);
    const { data, error: sendError } = await resend.emails.send({
      from: 'JOGALIBRE <info@jogalibre.com>',
      to: [user.email],
      subject: subject,
      html: html,
    });

    if (sendError) {
      console.error("メール送信失敗:", sendError);
      return;
    }

    console.log("メール送信成功。データ:", data);

  } catch (e) {
    console.error("例外発生:", e);
  }
}

run();
