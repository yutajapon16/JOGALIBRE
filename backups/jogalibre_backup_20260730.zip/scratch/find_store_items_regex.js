async function run() {
  const url = 'https://auctions.yahoo.co.jp/search/search?p=%E3%82%B8%E3%83%A3%E3%83%B3%E3%82%AF&istg=1';
  console.log('Searching:', url);
  
  const response = await fetch(url, { 
    headers: { 
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' 
    } 
  });
  const html = await response.text();
  const fs = require('fs');
  fs.writeFileSync('scratch/search_result.html', html);
  console.log('Saved search_result.html');
  
  // オークションURLを正規表現で抽出
  const urlRegex = /href="(https:\/\/(?:page\.)?auctions\.yahoo\.co\.jp\/jp\/auction\/[a-zA-Z0-9]+)"/gi;
  const urls = [];
  let match;
  while ((match = urlRegex.exec(html)) !== null) {
    const itemUrl = match[1];
    if (!urls.includes(itemUrl)) {
      urls.push(itemUrl);
    }
  }

  console.log(`Found ${urls.length} candidate URLs.`);
  
  for (const itemUrl of urls.slice(0, 10)) {
    console.log(`\nTesting: ${itemUrl}`);
    try {
      const res = await fetch(itemUrl, {
        headers: { 
          'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' 
        }
      });
      const itemHtml = await res.text();
      fs.writeFileSync('scratch/store_item.html', itemHtml);
      console.log('Saved store_item.html');
      
      // iframeがあるか探す
      const iframes = [];
      const iframeMatches = itemHtml.match(/<iframe[\s\S]*?>/gi);
      if (iframeMatches) {
        for (const iframeTag of iframeMatches) {
          const srcMatch = iframeTag.match(/src\s*=\s*["']([^"']*)["']/i);
          if (srcMatch) {
            iframes.push(srcMatch[1]);
          }
        }
      }
      
      console.log('Iframes found:', iframes);
      
      // もしiframeに商品説明用ドメインが含まれていれば、ヤフオクストア商品であると判断
      const storeIframe = iframes.find(src => 
        src.includes('show/description') || 
        src.includes('auctions.yahoo.co.jp/html') || 
        src.includes('auct-store.yahoo') || 
        src.includes('shopping.yahoo')
      );
      
      if (storeIframe) {
        console.log('✨ SUCCESS: Found Store Item with Description Iframe!');
        console.log('Store Iframe URL:', storeIframe);
        console.log('Use this URL for API testing:', itemUrl);
        break;
      }
    } catch (e) {
      console.error('Error fetching item:', e.message);
    }
  }
}

run();
