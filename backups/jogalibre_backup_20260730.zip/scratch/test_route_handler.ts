import * as dotenv from 'dotenv';
dotenv.config({ path: '.env.local' });
import { GET } from '../app/api/cron/export-orders/route';

async function testAuth() {
  console.log("CRON_SECRET in env:", process.env.CRON_SECRET);

  // 1. ヘッダーなしでリクエストを投げる (401になるはず)
  console.log("\n--- Test 1: No Auth Header ---");
  const req1 = new Request("http://localhost/api/cron/export-orders", {
    method: "GET"
  });
  const res1 = await GET(req1);
  console.log("Status:", res1.status);
  const text1 = await res1.text();
  console.log("Body:", text1);

  // 2. 間違ったトークンでリクエストを投げる (401になるはず)
  console.log("\n--- Test 2: Invalid Auth Header ---");
  const req2 = new Request("http://localhost/api/cron/export-orders", {
    method: "GET",
    headers: {
      "Authorization": "Bearer wrong_secret"
    }
  });
  const res2 = await GET(req2);
  console.log("Status:", res2.status);
  const text2 = await res2.text();
  console.log("Body:", text2);

  // 3. 正しいトークンでリクエストを投げる (200になるはず)
  console.log("\n--- Test 3: Correct Auth Header ---");
  const req3 = new Request("http://localhost/api/cron/export-orders", {
    method: "GET",
    headers: {
      "Authorization": `Bearer ${process.env.CRON_SECRET}`
    }
  });
  const res3 = await GET(req3);
  console.log("Status:", res3.status);
  const json3 = await res3.json();
  console.log("Body:", JSON.stringify(json3));
}

testAuth().catch(console.error);
