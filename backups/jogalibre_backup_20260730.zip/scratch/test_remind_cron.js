const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function run() {
  console.log("=== 未ログイン催促メール抽出のテストシミュレーション ===");
  try {
    const fiveDaysAgo = new Date();
    fiveDaysAgo.setDate(fiveDaysAgo.getDate() - 5);
    console.log("5日前の閾値:", fiveDaysAgo.toISOString());

    // 1. user_roles から role=customer/agent かつ last_login_reminded_at IS NULL を取得
    const { data: users, error: fetchError } = await supabase
      .from('user_roles')
      .select('id, email, full_name, role, language, last_login_at, created_at')
      .in('role', ['customer', 'agent'])
      .is('last_login_reminded_at', null);

    if (fetchError) {
      console.error("ユーザー取得失敗:", fetchError);
      return;
    }

    console.log(`未送信ユーザーの総数: ${users.length}件`);

    // 2. 日付条件フィルタ
    const targetUsers = users.filter(user => {
      if (user.last_login_at) {
        return new Date(user.last_login_at).getTime() <= fiveDaysAgo.getTime();
      } else if (user.created_at) {
        return new Date(user.created_at).getTime() <= fiveDaysAgo.getTime();
      }
      return false;
    });

    console.log(`日付条件（5日以上ログインなし/登録後5日経過）に合致する対象者: ${targetUsers.length}件`);
    targetUsers.forEach(u => {
      console.log(`- Email: ${u.email}`);
      console.log(`  Name: ${u.full_name}, Role: ${u.role}, Lang: ${u.language}`);
      console.log(`  LastLoginAt: ${u.last_login_at}, CreatedAt: ${u.created_at}`);
      console.log('-----------------------------');
    });

    console.log("シミュレーション終了。");

  } catch (e) {
    console.error("エラー:", e);
  }
}

run();
