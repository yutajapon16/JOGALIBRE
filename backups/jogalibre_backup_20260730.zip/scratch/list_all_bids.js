const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  try {
    console.log("Listing recent bid_requests...");
    const { data: bids, error: bidsError } = await supabase
      .from('bid_requests')
      .select('id, product_title, customer_id, customer_email, created_at')
      .order('created_at', { ascending: false })
      .limit(50);

    if (bidsError) {
      console.error("Error fetching bids:", bidsError);
    } else {
      console.log(`Total bid_requests fetched: ${bids.length}`);
      bids.forEach(b => {
        console.log(` - ID: ${b.id}, Title: ${b.product_title.substring(0, 20)}..., CustomerID: ${b.customer_id}, Email: ${b.customer_email}, Date: ${b.created_at}`);
      });
    }
  } catch (e) {
    console.error("Script exception:", e);
  }
}

run();
