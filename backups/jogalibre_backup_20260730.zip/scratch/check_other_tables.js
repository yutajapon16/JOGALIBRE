const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function checkTable(tableName, dateCol = 'created_at') {
  console.log(`\n--- ${tableName} テーブル (2026/06/18以降) ---`);
  try {
    const { data, error } = await supabase
      .from(tableName)
      .select('*')
      .gte(dateCol, '2026-06-18T00:00:00Z')
      .order(dateCol, { ascending: false })
      .limit(10);

    if (error) {
      console.error("エラー:", error);
      return;
    }

    console.log(`件数: ${data.length}件`);
    data.forEach(d => {
      console.log(`- ID: ${d.id}, CreatedAt: ${d[dateCol] || d.created_at}, Data:`, JSON.stringify(d).substring(0, 150));
    });
  } catch (e) {
    console.error("例外:", e);
  }
}

async function run() {
  await checkTable('favorites');
  await checkTable('deposits');
  // user_rolesは updated_at もしくは created_at
  // schemaを確認するために直接最新10件
  console.log(`\n--- user_roles テーブル (最新10件) ---`);
  try {
    const { data, error } = await supabase
      .from('user_roles')
      .select('*')
      .order('id', { ascending: false })
      .limit(10);
    if (error) {
      console.error("エラー:", error);
    } else {
      console.log(`件数: ${data.length}件`);
      data.forEach(d => {
        console.log(`- Email: ${d.email}, Role: ${d.role}, Name: ${d.full_name}, CreatedAt: ${d.created_at || d.terms_accepted_at}`);
      });
    }
  } catch (e) {
    console.error("例外:", e);
  }
}

run();
