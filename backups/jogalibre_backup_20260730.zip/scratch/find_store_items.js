const cheerio = require('cheerio');
const fs = require('fs');

async function run() {
  // 「ジャンク」などのキーワードでストア出品に限定して検索 (istg=1)
  const url = 'https://auctions.yahoo.co.jp/search/search?p=%E3%82%B8%E3%83%A3%E3%83%B3%E3%82%AF&istg=1';
  console.log('Searching:', url);
  
  const response = await fetch(url, { 
    headers: { 
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' 
    } 
  });
  const html = await response.text();
  const $ = cheerio.load(html);
  
  const urls = [];
  $('.Product, .Product__item').each((i, el) => {
    const $el = $(el);
    // 「ストア」アイコンまたは表記があるか
    const isStore = $el.text().includes('ストア') || $el.find('.Product__icon--store').length > 0 || $el.find('span:contains("ストア")').length > 0;
    const href = $el.find('a[href*="/auction/"], a[href*="/item/"]').attr('href');
    if (href) {
      urls.push({ href, isStore });
    }
  });

  console.log(`Found ${urls.length} items.`);
  const storeItems = urls.filter(u => u.isStore);
  console.log(`Store items: ${storeItems.length}`);
  
  for (const item of urls.slice(0, 5)) {
    console.log(`\nTesting item: ${item.href} (Store: ${item.isStore})`);
    try {
      const res = await fetch(item.href, {
        headers: { 
          'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' 
        }
      });
      const itemHtml = await res.text();
      
      // iframeをすべて抽出してログ出力
      const iframes = [];
      const iframeRegex = /<iframe[^>]*src="([^"]*)"[^>]*>/gi;
      let match;
      while ((match = iframeRegex.exec(itemHtml)) !== null) {
        iframes.push(match[1]);
      }
      
      console.log('Iframes found:', iframes);
      
      // ProductDescription__body や Explanation などの周りも確認
      const explanationAreaMatch = itemHtml.match(/<(?:div|section)[^>]*(?:id|class)="[^"]*(?:Explanation|ProductDescription)[^"]*"[^>]*>([\s\S]*?)<\/(?:div|section)>/i);
      console.log('Explanation block matched:', explanationAreaMatch ? 'Yes' : 'No');
      if (explanationAreaMatch) {
        console.log('Block snippet:', explanationAreaMatch[1].substring(0, 200));
      }
    } catch (e) {
      console.error('Error fetching item:', e.message);
    }
  }
}

run();
