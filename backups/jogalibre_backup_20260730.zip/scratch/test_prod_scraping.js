async function testProdScraping() {
  const prodUrl = 'https://jogalibre.vercel.app/api/yahoo-product';
  const targetAuctionUrl = 'https://auctions.yahoo.co.jp/jp/auction/1234475905';
  
  console.log(`本番APIへリクエスト送信中: ${prodUrl}`);
  try {
    const res = await fetch(prodUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        url: targetAuctionUrl,
        lang: 'ja',
        skipDescription: true,
        skipAiSummary: true
      })
    });
    
    console.log(`ステータスコード: ${res.status} ${res.statusText}`);
    const text = await res.text();
    console.log("レスポンス内容:");
    try {
      const json = JSON.parse(text);
      console.log(JSON.stringify(json, null, 2));
    } catch {
      console.log(text.substring(0, 500));
    }
  } catch (e) {
    console.error("通信エラー:", e);
  }
}

testProdScraping();
