const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function run() {
  try {
    // 1. C001 の user_role レコードを取得して UUID を特定
    const { data: userData, error: userError } = await supabase
      .from('user_roles')
      .select('id, email, role, customer_id')
      .eq('customer_id', 'C001')
      .maybeSingle();

    if (userError) {
      console.error("Error fetching C001 user info:", userError);
      return;
    }

    if (!userData) {
      console.log("No user found with customer_id = 'C001'");
      return;
    }

    const uuid = userData.id;
    console.log(`Found C001 User Info: UUID = ${uuid}, Email = ${userData.email}`);

    // 2. bid_requests テーブルの確認 (customer_id は UUID型)
    const { data: bids, error: bidsError } = await supabase
      .from('bid_requests')
      .select('id, product_title, customer_id, customer_email, created_at')
      .eq('customer_id', uuid);

    if (bidsError) {
      console.error("Error fetching bid_requests:", bidsError);
    } else {
      console.log(`Found ${bids.length} bid_requests for C001 UUID:`);
      bids.forEach(b => console.log(` - ID: ${b.id}, Title: ${b.product_title}, Date: ${b.created_at}`));
    }

    // 3. deposits テーブルの確認 (customer_id は TEXT型 "C001")
    const { data: deposits, error: depositsError } = await supabase
      .from('deposits')
      .select('id, customer_id, amount, deposit_date')
      .eq('customer_id', 'C001');

    if (depositsError) {
      console.error("Error fetching deposits:", depositsError);
    } else {
      console.log(`Found ${deposits.length} deposits for C001 ID:`);
      deposits.forEach(d => console.log(` - ID: ${d.id}, Amount: ${d.amount}, Date: ${d.deposit_date}`));
    }

    // 4. favorites テーブルの確認 (user_id は UUID型)
    const { data: favorites, error: favsError } = await supabase
      .from('favorites')
      .select('*')
      .eq('user_id', uuid);

    if (favsError) {
      console.error("Error fetching favorites:", favsError);
    } else {
      console.log(`Found ${favorites.length} favorites for C001 UUID.`);
    }

  } catch (e) {
    console.error("Script exception:", e);
  }
}

run();
